package com.gospel.xdevice.rebottest.runner;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.HandlerThread;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.android.uiautomator.core.EventListener;
import com.android.uiautomator.core.ShellUiAutomatorBridge;
import com.android.uiautomator.core.UiAutomationShellWrapper;
import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.gospel.xdevice.rebottest.log.Logger;
import com.gospel.xdevice.rebottest.model.NodeInfo;
import com.gospel.xdevice.rebottest.model.RecordInfo;
import com.gospel.xdevice.rebottest.utils.RecordAction;
import com.gospel.xdevice.rebottest.utils.RecordManager;
import com.gospel.xdevice.rebottest.utils.Utils;
import com.gospel.xdevice.rebottest.utils.Utils.LOCALTYPE;

/**
 * UiAutomator
 * 
 * @author y00202274
 */
@SuppressLint("NewApi")
public class UiAutomatorRunner {

	private static String TAG = "robot_UiAutomatorRunner";
	public static String appName = "SoftRobot";

	public static boolean bRecord = false;
	private final Object mLock = new Object();
	// 是否启动录制
	public static boolean isStartRecord = false;
	private static boolean isScrollFind = false;// 是否是滑动查找控件
	private static boolean isUpDownScroll = false;
	private static boolean isLeftRightScroll = false;

	//
	private List<NodeInfo> curWindowNodeInfo = new ArrayList<NodeInfo>();
	private List<AccessibilityNodeInfo> WinRootNodesList = new ArrayList<AccessibilityNodeInfo>();
	private List<List<NodeInfo>> WindowsNodeInfo = new ArrayList<List<NodeInfo>>();

	private static UiAutomatorRunner uiAutomatorRunner;
	private static HandlerThread handlerThread;
	private static UiAutomationShellWrapper uiAutomationShellWrapper;

	/*
	 * mMonkey设置为true时，在调用u,r后会导致手机侧的有些view控件不能正常被点击；
	 * 比如：切换语言、开发者选项、联系人设置中的"联系人显示"等
	 */
	private boolean mMonkey = false;
	private UiEventListener listener;
	private static UiDevice uiDevice;

	// zwx235140 2016/6/13
	private static UiObject mUiObject = null;

	// 记录是否产生了第一次有效的点击
	// 只有产生并缓存了第一条记录之后，才可以开始缓存其他记录
	public static boolean clickFirst = false;

	public static UiAutomatorRunner getInstance() {
		Logger.i(TAG, "invoke UiAutomatorRunner getInstance,pid:"
				+ android.os.Process.myPid());
		if (uiAutomatorRunner == null) {
			Logger.i(TAG, "uiAutomatorRunner Instance == null");
			uiAutomatorRunner = new UiAutomatorRunner();

		}
		/*
		 * 处理N版本存在弹框后再次无法点击界面控件问题， 获取根节点失败后，重置相关连接
		 */
		// ###########Begin zwx235140 2016/6/13##########
		else {
			/*
			 * 在连接成功之后，有出现非代码操作导致的连接断连 uiAutomatorRunner 不为null，但实际已断连 20160827
			 */
			if (uiAutomationShellWrapper != null
					&& !uiAutomationShellWrapper.isConnected()) {
				// 连接已异常断连，先重置连接
				Logger.i(TAG,
						"the uiautomation connection is broken.Reconnect it.");
				resetRunner();
			}

			if (mUiObject == null) {
				mUiObject = new UiObject(new UiSelector());
			}

			if (mUiObject.getRootNode() == null) {
				Logger.i(TAG, "root node is null! reset UiAutomatorRunner!");
				resetRunner();
			}
		}
		// ###########End zwx2351402016/6/13##########
		return uiAutomatorRunner;
	}

	public static void resetRunner() {
		Logger.i(TAG, "reset UiAutomatorRunner!");
		if (uiAutomatorRunner != null) {
			if (uiAutomationShellWrapper != null) {
				try {
					uiAutomationShellWrapper.disconnect();
				} catch (Exception e) {
					Logger.e(TAG, "disconnect error. " + e.getMessage());
				}
			}
			if (handlerThread != null) {
				handlerThread.quit();
			}
			uiAutomatorRunner = null;
			uiAutomatorRunner = new UiAutomatorRunner();
		}
	}

	public UiAutomatorRunner() {
		start();
	}

	public boolean initialize() {
		Logger.i(TAG, "invoke initialize uiAutomatorRunner");
		if (uiAutomatorRunner == null) {
			Logger.i(TAG, "uiAutomatorRunner==null");
			start();
		}
		return true;
	}

	public boolean start() {
		Logger.i(TAG, "invoke start UiAutomatorHandlerThread");
		try {
			handlerThread = new HandlerThread("UiAutomatorHandlerThread");
			handlerThread.setDaemon(true);
			handlerThread.start();

			uiAutomationShellWrapper = new UiAutomationShellWrapper();

			Logger.i(TAG, " UiAutomationShellWrapper.connect() begin");
			uiAutomationShellWrapper.connect();
			Logger.i(TAG, " UiAutomationShellWrapper.connect() end");

			uiAutomationShellWrapper.setRunAsMonkey(mMonkey);
			uiDevice = UiDevice.getInstance();
			uiDevice.initialize(new ShellUiAutomatorBridge(
					uiAutomationShellWrapper.getUiAutomation()));

			/**
			 * 解决问题: 3、联系人模块，桌面快捷方式点击进入信息模块，
			 * commom下的checkIfTextExist和checkIfIdExist和modle下的checkWidget检查有问题
			 * ，使用这三个方法检查都失败，并且在短信界面输入8
			 */
			// UiWatcherManager.registerWatcher(uiDevice);
			// uiDevice.runWatchers();

			// Logger.i(TAG, "addEventListener");
			// listener = new UiEventListener();
			// uiDevice.addEventListener(listener);
			Logger.i(TAG, "UiAutomatorRunner initialize ok");
			return true;
		} catch (Exception localException) {
			Logger.e(
					"UiAutomatorRunner start ERROR!",
					localException.getClass() + ":"
							+ localException.getMessage() + ".getCause:"
							+ localException.getCause());
			// uiAutomatorRunner = null;
		}

		return false;
	}

	public void stop() {
		uiDevice.removeEventListener(listener);
		uiAutomationShellWrapper.disconnect();
		handlerThread.quit();
		uiAutomatorRunner = null;
	}

	public void addListener() {
		if (listener == null) {
			listener = new UiEventListener();
			uiDevice.addEventListener(listener);
		}
	}

	public void removeListener() {
		if (listener != null) {
			uiDevice.removeEventListener(listener);
			listener = null;
		}
	}

	public static UiDevice getUiDevice() {
		return uiDevice;
	}

	public void setUiDevice(UiDevice uiDevice) {
		UiAutomatorRunner.uiDevice = uiDevice;
	}

	@SuppressLint("DefaultLocale")
	private class UiEventListener implements EventListener {

		private String first_click_event_packname = "";

		@Override
		public void onAccessibilityEvent(AccessibilityEvent event) {

			if (!bRecord) {
				// Logger.i(TAG, "record already stoped!");
				return;
			}
			// 过滤掉录制界面的任何事件
			if ((event.getPackageName() != null)
					&& (event.getPackageName()
							.equals("com.gospel.xdevice.rebottest"))) {
				return;
			}
			synchronized (mLock) {
				// Logger.i(TAG, "EventTpye---------------" +
				// event.getSource());
				// Logger.i(TAG, "EventTpye---------------" + event.toString());

				// Logger.i(TAG,
				// "robottest receive a AccessibilityEvent------------: "
				// + event.toString());

				int eventType = event.getEventType();
				String eventName = AccessibilityEvent
						.eventTypeToString(eventType);
				// Logger.i(TAG, "eventName: " + eventName);
				switch (eventType) {
				case AccessibilityEvent.TYPE_VIEW_CLICKED:
					Logger.i(TAG, "**********TYPE_VIEW_CLICKED**************");
					Logger.i(TAG, "【       " + event.getEventTime() + "   】");
					Logger.i(TAG, "**********");
					Logger.i(TAG, "FromTo**********" + event.getFromIndex()
							+ " 到  " + event.getToIndex());
					// AccessibilityNodeInfo node = event.getSource();
					AccessibilityNodeInfo nodeClick = event.getSource();
					if (!event.getPackageName().equals(
							"com.gospel.xdevice.rebottest")) {
						// clickFirst = (Boolean)
						// Utils.getDataFromFile(MyApplication.getContext(),"clickFirst",
						// "bool");
						if (clickFirst) {
							RecordManager.clearRecord();
							// 产生了第一次有效的点击事件
							// Logger.i(TAG, "第一次点击，进入到主页面。。。。。。。。。。。。。。。");
							first_click_event_packname = (String) event
									.getPackageName();
							// Logger.i(TAG, "MainActivityName:" + appName + ","
							// + first_click_event_packname);
							curWindowNodeInfo.clear();
							WinRootNodesList.clear();
							WindowsNodeInfo.clear();
						} else {
							// 缓存控件点击记录
							// 过滤掉其本身相关的点击事件
							if ((nodeClick.getText() == null)
									|| !nodeClick.getText().equals(appName)) {
								// Logger.i(TAG, "点击，缓存点击信息。。。。。。。。。。。。。。。");

								// 缓存当前窗口的rootNode
								// AccessibilityNodeInfo tempNode = Utils
								// .getRootNode();
								// List<AccessibilityNodeInfo>
								// laAccessibilityNodeInfos = tempNode
								// .findAccessibilityNodeInfosByViewId("com.android.contacts:id/contacts_dialpad");
								String pid = null;
								if (nodeClick.getParent() != null
										&& nodeClick.getParent().getParent() != null
										&& nodeClick.getParent().getParent()
												.getParent() != null
										&& nodeClick.getParent().getParent()
												.getParent()
												.getViewIdResourceName() != null) {
									pid = nodeClick.getParent().getParent()
											.getParent()
											.getViewIdResourceName();
								}
								Logger.i(TAG, "当前点击的viewID 父类 : " + pid);
								Logger.i(
										TAG,
										"当前点击的viewID  : "
												+ nodeClick
														.getViewIdResourceName());
								if (pid != null
										&& pid.length() > 0
										&& "com.android.contacts:id/dialer_container"// "com.android.contacts:id/contacts_dialpad"
										.equals(pid)) {
									// 向上取三级比较recource-id

									RecordInfo record = new RecordInfo();
									record.setActionType(RecordAction.ACTION_CLICK);
									// record.setNode(nodeClick,
									// curWindowNodeInfo, WindowsNodeInfo);
									record.setLocalType(LOCALTYPE.AXIS);
									record.setNodeX(nodeClick
											.getBoundsInScreen().centerX());
									record.setNodeY(nodeClick
											.getBoundsInScreen().centerY());
									record.setFormIndex(event.getFromIndex());
									record.setTodIndex(event.getToIndex());
									record.setDesc(nodeClick
											.getContentDescription().toString());
									UiSelector uiSelector = new UiSelector();
									uiSelector = new UiSelector()
											.className(
													"android.widget.RelativeLayout")
											.childSelector(
													new UiSelector()
															.className("android.widget.EditText"));
									UiObject uiobj = new UiObject(uiSelector);
									record.setUiobj(uiobj);
									record.setUiSelector(uiSelector);
									Logger.i(TAG, "desc::" + record.getDesc());
									try {
										Logger.i(TAG, "uiobj::"
												+ record.getUiobj().getBounds()
														.toString());
									} catch (UiObjectNotFoundException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									RecordManager.addRecord(record);
								} else {
									Logger.i(TAG,
											"TYPE_VIEW_CLICKED 不是拨号键盘输入事件。");
									RecordInfo record = new RecordInfo();
									if (isScrollFind) {
										record.setScroll(isScrollFind);
										record.setUpDownScroll(isUpDownScroll);
										record.setLeftRightScroll(isLeftRightScroll);
									}
									record.setActionType(RecordAction.ACTION_CLICK);
									// Logger.i(TAG,event.toString());

									record.setNode(nodeClick,
											curWindowNodeInfo, WindowsNodeInfo);
									// record.parseNode(nodeClick,WinRootNodesList);
									// Logger.i(TAG,
									// "把当前的rootNode加入到RecordInfo里面");
									// Logger.i(TAG, "当前node的boundInScreen："
									// + nodeClick.getBoundsInScreen()
									// .toString() + "packageName:"
									// + nodeClick.getPackageName().toString());
									// 打印
									int size = curWindowNodeInfo.size();
									// Logger.i(TAG, "当前窗口的node个数为 : " + size);
									// if (size > 0) {
									// for (NodeInfo nodeInfo :
									// curWindowNodeInfo) {
									// Logger.i(
									// TAG,
									// "id: "
									// + nodeInfo.getId()
									// + " Text: "
									// + nodeInfo.getText()
									// + " class: "
									// + nodeInfo
									// .getClassName()
									// + " rect: "
									// + nodeInfo
									// .getBouondInScreen());
									// }
									// }
									// Logger.i(TAG,
									// "RecordManager.addRecord >>> "
									// + record.toString());
									record.setFormIndex(event.getFromIndex());
									record.setTodIndex(event.getToIndex());
									RecordManager.addRecord(record);
									// Logger.i(TAG, "clickisScrollFind:"
									// + isScrollFind);
									// Logger.i(TAG,
									// "add click data.  " + record.toString());
									// Logger.i(TAG,
									// "AccessibilityEvent.TYPE_VIEW_CLICKED");
									// Logger.i(TAG, event.toString());
									// Logger.i(TAG,
									// "清除WindowsNodeInfo信息。。。。。。。。。。。。。。。。。。。。");
								}
								curWindowNodeInfo.clear();
								WinRootNodesList.clear();
								WindowsNodeInfo.clear();
							}

						}

					}
					// reset scroll
					isScrollFind = false;
					isLeftRightScroll = false;
					isUpDownScroll = false;
					break;

				case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
					// 窗口状态发生变化，例如打开新的窗口界面
					// Logger.i(TAG,
					// "*******TYPE_WINDOW_STATE_CHANGED:窗口状态发生变化********");
					Logger.i(TAG,
							"**********TYPE_WINDOW_STATE_CHANGED***************");
					Logger.i(TAG, "【       " + event.getEventTime() + "   】");
					Logger.i(TAG, "**********");
					Logger.i(TAG, "FromTo**********" + event.getFromIndex()
							+ " 到  " + event.getToIndex());
					// 缓存当前窗口的rootNode
					AccessibilityNodeInfo tempNode = Utils.getRootNode();
					if (tempNode == null) {
						return;
					}
					// WinRootNodesList.add(event.getSource());
					// 重新分配新内存地址
					curWindowNodeInfo = new ArrayList<NodeInfo>();
					// curWindowRootNode = event.getSource();
					// AccessibilityNodeInfo nodeWindowState =
					// event.getSource();
					// //
					int childCount = tempNode.getChildCount();
					if (childCount > 0) {
						for (int i = 0; i < childCount; i++) {
							getChildRecursive(tempNode.getChild(i));
						}
					}
					// Logger.i(TAG, "state_changed 缓存当前窗口的rootNode:node size:"
					// + curWindowNodeInfo.size());
					WindowsNodeInfo.add(curWindowNodeInfo);
					if (tempNode != null) {
						// Logger.i(TAG,
						// "AccessibilityEvent.:" + tempNode.toString());
					}
					if (clickFirst) {
						if (!event.getPackageName().equals(
								first_click_event_packname)) {
							// 缓存第一次有效的控件点击进入的acticity界面信息
							String activityName = Utils.getActivityName();
							RecordInfo record = new RecordInfo();
							record.setActionType(RecordAction.ACTION_STARTACTIVITY);
							record.setActivityName(activityName);
							// Logger.i(TAG, "RecordManager.addRecord >>> "
							// + record.toString());
							record.setFormIndex(event.getFromIndex());
							record.setTodIndex(event.getToIndex());
							RecordManager.addRecord(record);
							clickFirst = false;
							// Logger.i(TAG, "clickFirst = false");
							// Logger.i(TAG, "firstPackageName:" +
							// activityName);
						}
					}
					break;
				case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:

					// Logger.i(TAG,
					// "****************TYPE_WINDOW_CONTENT_CHANGED:窗口内容发生变化*************");
					// // 缓存当前窗口的rootNode
					// curWindowRootNode = Utils.getRootNode();
					// tempNode = Utils.getRootNode();
					//
					// if (tempNode == null) {
					// return;
					// }
					//
					// WinRootNodesList.add(event.getSource());
					// // 重新分配新内存地址
					// curWindowNodeInfo = new ArrayList<NodeInfo>();
					//
					// curWindowRootNode = event.getSource();
					// AccessibilityNodeInfo nodeWindowState =
					// event.getSource();
					// childCount = tempNode.getChildCount();
					// if (childCount > 0) {
					// for (int i = 0; i < childCount; i++) {
					// getChildRecursive(tempNode.getChild(i));
					// }
					// }
					// Logger.i(TAG, "state_changed 缓存当前窗口的rootNode:node size:"
					// + curWindowNodeInfo.size());
					// WindowsNodeInfo.add(curWindowNodeInfo);
					// if (tempNode != null) {
					// Logger.i(TAG,
					// "AccessibilityEvent.:" + tempNode.toString());
					// }
					break;
				case AccessibilityEvent.TYPE_VIEW_SCROLLED:
					Logger.i(TAG, "AccessibilityEvent.TYPE_VIEW_SCROLLED");
					Logger.i(TAG, "**********TYPE_VIEW_SCROLLED*********");
					Logger.i(TAG, "【       " + event.getEventTime() + "   】");
					Logger.i(TAG, "**********");
					Logger.i(TAG, "FromTo**********" + event.getFromIndex()
							+ " 到  " + event.getToIndex());
					// 缓存当前窗口的rootNode
					tempNode = Utils.getRootNode();
					if (tempNode == null) {
						return;
					}
					// WinRootNodesList.add(event.getSource());
					// curWindowNodeInfo.clear();
					// 重新分配地址
					curWindowNodeInfo = new ArrayList<NodeInfo>();
					childCount = tempNode.getChildCount();
					if (childCount > 0) {
						for (int i = 0; i < childCount; i++) {
							getChildRecursive(tempNode.getChild(i));
						}
					}
					// Logger.i(TAG,
					// "view_scrolled 缓存当前窗口的rootNode:node size:"
					// + curWindowNodeInfo.size()
					// + curWindowNodeInfo.get(0).getPackageName());
					WindowsNodeInfo.add(curWindowNodeInfo);
					if (tempNode != null) {
						// Logger.i(TAG,
						// "AccessibilityEvent.:" + tempNode.toString());
					}
					if (safeCharSeqToString(event.getContentDescription()) != null
							&& safeCharSeqToString(
									event.getContentDescription()).contains(
									"Screen")) {
						// left,right scroll
						isScrollFind = true;
						isLeftRightScroll = true;
						isUpDownScroll = false;
						Logger.i("RecordInfo:",
								"scroll left rght isScrollFind:" + isScrollFind);
					} else {
						// up,down scroll
						isScrollFind = true;
						isLeftRightScroll = false;
						isUpDownScroll = true;
						Logger.i(TAG, "scroll up down isScrollFind:"
								+ isScrollFind);

					}
					// Logger.i(TAG, "AccessibilityEvent.TYPE_VIEW_SCROLLED:"
					// + event.toString());

					// AccessibilityNodeInfo node2 = event.getSource();
					// Logger.i(TAG, "AccessibilityEvent.TYPE_VIEW_SCROLLED:"
					// + event.toString());
					// Logger.i(TAG, "AccessibilityEvent.TYPE_VIEW_SCROLLED:"
					// + node2.toString());
					// RecordInfo recordSwipe = new RecordInfo();
					// recordSwipe.setActionType(RecordAction.ACTION_SWIPE);
					// recordSwipe.setNode(event.getSource(), curWindowNodeInfo,
					// WindowsNodeInfo);
					// RecordManager.addRecord(recordSwipe);

					break;
				case AccessibilityEvent.TYPE_VIEW_FOCUSED:
					Logger.i(TAG, "**********TYPE_VIEW_FOCUSED*************");
					Logger.i(TAG, "【       " + event.getEventTime() + "   】");
					Logger.i(TAG, "**********");
					Logger.i(TAG, "FromTo********" + event.getFromIndex()
							+ " 到  " + event.getToIndex());
					tempNode = Utils.getRootNode();
					if (tempNode == null) {
						return;
					}
					// 重新分配地址
					curWindowNodeInfo = new ArrayList<NodeInfo>();
					childCount = tempNode.getChildCount();
					if (childCount > 0) {
						for (int i = 0; i < childCount; i++) {
							getChildRecursive(tempNode.getChild(i));
						}
					}
					// Logger.i(TAG,
					// "TYPE_VIEW_FOCUSED 缓存当前窗口的rootNode:node size:"
					// + curWindowNodeInfo.size()
					// + curWindowNodeInfo.get(0).getPackageName());
					WindowsNodeInfo.add(curWindowNodeInfo);
					// Logger.i(TAG, "TYPE_VIEW_FOCUSED");
					// Logger.i(TAG, "TYPE_VIEW_FOCUSED Event:" +
					// event.toString());
					// List<AccessibilityNodeInfo> laAccessibilityNodeInfos1 =
					// tempNode
					// .findAccessibilityNodeInfosByViewId("com.android.contacts:id/contacts_dialpad");
					// Logger.i(TAG, "TYPE_VIEW_FOCUSED 获取拨号键盘信息:");
					// if (laAccessibilityNodeInfos1 == null
					// || laAccessibilityNodeInfos1.size() <= 0) {
					// Logger.i(TAG, "TYPE_VIEW_FOCUSED 不是拨号键盘输入事件。");
					List<AccessibilityNodeInfo> laAccessibilityNodeInfos = tempNode
							.findAccessibilityNodeInfosByViewId("com.android.contacts:id/contacts_dialpad");
					if (laAccessibilityNodeInfos != null
							&& laAccessibilityNodeInfos.size() > 0) {
						Logger.i(TAG,
								"TYPE_VIEW_FOCUSED 监听到拨号键盘输入事件。  sourcesId: "
										+ laAccessibilityNodeInfos.get(0)
												.getViewIdResourceName());
						// RecordInfo record = new RecordInfo();
						// record.setActionType(RecordAction.ACTION_FOCUSED);
						// record.setLocalType(LOCALTYPE.AXIS);
						// record.setNodeX(event.getSource().getBoundsInScreen()
						// .centerX());
						// record.setNodeY(event.getSource().getBoundsInScreen()
						// .centerY());
						// record.setFormIndex(event.getFromIndex());
						// record.setTodIndex(event.getToIndex());
						// RecordManager.addRecord(record);
					} else {
						Logger.i(TAG, "TYPE_VIEW_FOCUSED 不是拨号键盘输入事件。");
						RecordInfo recordFocus = new RecordInfo();
						recordFocus.setActionType(RecordAction.ACTION_FOCUSED);
						recordFocus.setNode(event.getSource(),
								curWindowNodeInfo, WindowsNodeInfo);
						// Logger.i(
						// TAG,
						// "RecordManager.addRecord >>> "
						// + recordFocus.toString());
						recordFocus.setFormIndex(event.getFromIndex());
						recordFocus.setTodIndex(event.getToIndex());
						RecordManager.addRecord(recordFocus);
					}
					// } else {
					// Logger.i(TAG,
					// "TYPE_VIEW_FOCUSED 监听到拨号键盘输入事件。  sourcesId: "
					// + laAccessibilityNodeInfos1.get(0)
					// .getViewIdResourceName());
					// }
					isScrollFind = false;
					isLeftRightScroll = false;
					isUpDownScroll = false;

					break;
				case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
					Logger.i(TAG,
							"**********TYPE_VIEW_TEXT_CHANGED*******************");
					Logger.i(TAG, "【       " + event.getEventTime() + "   】");
					Logger.i(TAG, "**********");
					Logger.i(TAG, "FromTo**********" + event.getFromIndex()
							+ " 到  " + event.getToIndex());
					tempNode = Utils.getRootNode();
					if (tempNode == null) {
						return;
					}

					// WinRootNodesList.add(event.getSource());
					// curWindowNodeInfo.clear();
					// 重新分配地址
					curWindowNodeInfo = new ArrayList<NodeInfo>();
					childCount = tempNode.getChildCount();
					if (childCount > 0) {
						for (int i = 0; i < childCount; i++) {
							getChildRecursive(tempNode.getChild(i));
						}
					}
					// Logger.i(TAG,
					// "TYPE_VIEW_TEXT_CHANGED 缓存当前窗口的rootNode:node size:"
					// + curWindowNodeInfo.size()
					// + curWindowNodeInfo.get(0).getPackageName());
					WindowsNodeInfo.add(curWindowNodeInfo);
					// Logger.i(TAG, "CONTENT_CHANGE_TYPE_TEXT");
					// Logger.i(
					// TAG,
					// "CONTENT_CHANGE_TYPE_TEXT Event:"
					// + event.toString());
					// 如果是拨号键盘则不记录文本输入事件
					// com.android.contacts:id/contacts_dialpad
					List<AccessibilityNodeInfo> laAccessibilityNodeInfos1 = tempNode
							.findAccessibilityNodeInfosByViewId("com.android.contacts:id/contacts_dialpad");
					if (laAccessibilityNodeInfos1 != null
							&& laAccessibilityNodeInfos1.size() > 0) {
						Logger.i(TAG,
								"TYPE_VIEW_TEXT_CHANGED 监听到拨号键盘输入事件。  sourcesId: "
										+ laAccessibilityNodeInfos1.get(0)
												.getViewIdResourceName());
						// RecordInfo record = new RecordInfo();
						// record.setActionType(RecordAction.ACTION_CLICK);
						// record.setLocalType(LOCALTYPE.AXIS);
						// record.setNodeX(event.getSource().getBoundsInScreen()
						// .centerX());
						// record.setNodeY(event.getSource().getBoundsInScreen()
						// .centerY());
						// // record.setNode(event.getSource(),
						// curWindowNodeInfo,
						// // WindowsNodeInfo);
						// record.setFormIndex(event.getFromIndex());
						// record.setTodIndex(event.getToIndex());
						// Logger.i(
						// TAG,
						// "RecordManager.addRecord >>> "
						// + record.toString());
						// RecordManager.addRecord(record);

					} else {
						Logger.i(TAG, "TYPE_VIEW_TEXT_CHANGED 不是拨号键盘输入事件。");
						RecordInfo record = new RecordInfo();
						record.setActionType(RecordAction.ACTION_INPUT);
						record.setNode(event.getSource(), curWindowNodeInfo,
								WindowsNodeInfo);
						record.setInput_text(event.getSource().getText()
								.toString());
						// Logger.i(TAG,
						// "RecordManager.addRecord >>> " + record.toString());
						record.setFormIndex(event.getFromIndex());
						record.setTodIndex(event.getToIndex());
						RecordManager.addRecord(record);
					}
					break;
				default:
					break;
				}
				mLock.notifyAll();
			}
		}
	}

	private static String safeCharSeqToString(CharSequence cs) {
		if (cs == null)
			return "";
		else {
			return stripInvalidXMLChars(cs);
		}
	}

	private static String stripInvalidXMLChars(CharSequence cs) {
		StringBuffer ret = new StringBuffer();
		char ch;
		/*
		 * http://www.w3.org/TR/xml11/#charsets [#x1-#x8], [#xB-#xC],
		 * [#xE-#x1F], [#x7F-#x84], [#x86-#x9F], [#xFDD0-#xFDDF],
		 * [#x1FFFE-#x1FFFF], [#x2FFFE-#x2FFFF], [#x3FFFE-#x3FFFF],
		 * [#x4FFFE-#x4FFFF], [#x5FFFE-#x5FFFF], [#x6FFFE-#x6FFFF],
		 * [#x7FFFE-#x7FFFF], [#x8FFFE-#x8FFFF], [#x9FFFE-#x9FFFF],
		 * [#xAFFFE-#xAFFFF], [#xBFFFE-#xBFFFF], [#xCFFFE-#xCFFFF],
		 * [#xDFFFE-#xDFFFF], [#xEFFFE-#xEFFFF], [#xFFFFE-#xFFFFF],
		 * [#x10FFFE-#x10FFFF].
		 */
		for (int i = 0; i < cs.length(); i++) {
			ch = cs.charAt(i);

			if ((ch >= 0x1 && ch <= 0x8) || (ch >= 0xB && ch <= 0xC)
					|| (ch >= 0xE && ch <= 0x1F) || (ch >= 0x7F && ch <= 0x84)
					|| (ch >= 0x86 && ch <= 0x9f)
					|| (ch >= 0xFDD0 && ch <= 0xFDDF)
					|| (ch >= 0x1FFFE && ch <= 0x1FFFF)
					|| (ch >= 0x2FFFE && ch <= 0x2FFFF)
					|| (ch >= 0x3FFFE && ch <= 0x3FFFF)
					|| (ch >= 0x4FFFE && ch <= 0x4FFFF)
					|| (ch >= 0x5FFFE && ch <= 0x5FFFF)
					|| (ch >= 0x6FFFE && ch <= 0x6FFFF)
					|| (ch >= 0x7FFFE && ch <= 0x7FFFF)
					|| (ch >= 0x8FFFE && ch <= 0x8FFFF)
					|| (ch >= 0x9FFFE && ch <= 0x9FFFF)
					|| (ch >= 0xAFFFE && ch <= 0xAFFFF)
					|| (ch >= 0xBFFFE && ch <= 0xBFFFF)
					|| (ch >= 0xCFFFE && ch <= 0xCFFFF)
					|| (ch >= 0xDFFFE && ch <= 0xDFFFF)
					|| (ch >= 0xEFFFE && ch <= 0xEFFFF)
					|| (ch >= 0xFFFFE && ch <= 0xFFFFF)
					|| (ch >= 0x10FFFE && ch <= 0x10FFFF))
				ret.append(".");
			else
				ret.append(ch);
		}
		return ret.toString();
	}

	private void getChildRecursive(AccessibilityNodeInfo node) {
		if (node != null) {
			// Logger.i(TAG,
			// "child widget info,id; " + node.getViewIdResourceName()
			// + " text: " + safeCharSeqToString(node.getText())
			// + " boundInScreen:"
			// + node.getBoundsInScreen().toString());
			NodeInfo nodeInfo = new NodeInfo();
			String id = node.getViewIdResourceName();
			String text = safeCharSeqToString(node.getText());
			nodeInfo.setClassName(safeCharSeqToString(node.getClassName()));
			nodeInfo.setPackageName(safeCharSeqToString(node.getPackageName()));
			Rect curRect = node.getBoundsInScreen();
			nodeInfo.setBouondInScreen(curRect);
			nodeInfo.setNode(node);
			if (Utils.isNullOrBlank(id)) {
				nodeInfo.setId("no id");
			} else {
				nodeInfo.setId(id);
			}
			if (Utils.isNullOrBlank(text)) {
				nodeInfo.setText("no text");
			} else {
				nodeInfo.setText(text);
			}
			curWindowNodeInfo.add(nodeInfo);

			int childCcount = node.getChildCount();
			if (childCcount > 0) {
				for (int i = 0; i < childCcount; i++) {
					getChildRecursive(node.getChild(i));
				}
			}
		}
	}
}