package com.gospel.xdevice.rebottest.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.gospel.xdevice.rebottest.FloatView;
import com.gospel.xdevice.rebottest.R;
import com.gospel.xdevice.rebottest.log.Logger;
import com.gospel.xdevice.rebottest.model.NodeInfoAction;
import com.gospel.xdevice.rebottest.model.RecordInfo;
import com.gospel.xdevice.rebottest.model.ScriptObj;
import com.gospel.xdevice.rebottest.runner.UiAutomatorRunner;
import com.gospel.xdevice.rebottest.utils.Adapter;
import com.gospel.xdevice.rebottest.utils.KeyboardUtil;
import com.gospel.xdevice.rebottest.utils.MyApplication;
import com.gospel.xdevice.rebottest.utils.RecordManager;
import com.gospel.xdevice.rebottest.utils.Utils;
import com.gospel.xdevice.rebottest.utils.Utils.LOCALTYPE;

@SuppressLint("HandlerLeak")
public class FloatWindowService extends Service {
	private static final String TAG = "FloatWindowService";
	View floatView;
	WindowManager mWindowManager;
	LayoutParams wmParams;
	int sW;
	int sH;
	public static List<RecordInfo> replayList = new ArrayList<RecordInfo>();
	LayoutParams eatParams;
	boolean hasAddEat = false;
	ImageView startRecord;
	ImageView stopRecord;
	ImageView backRecord;
	Boolean isStartRecord = false;
	Boolean isStartPlay = true;
	View mFloatView;
	View mContainView;
	View mSettingsView;
	ListView listView;
	FloatView mFloatImageView;
	LayoutParams wmFloatParams;
	LayoutParams wmContainParams;
	LayoutParams wmSettingsParams;
	LayoutParams wmErrorViewParams;
	ImageView setting;
	String replayName;
	List<String> fileList = new ArrayList<String>();
	public static final float MINDIS = 0.1f;
	WindowManager.LayoutParams mWmParams;
	public int mFloatViewSize;
	public int mfloatViewTopSize;
	public int mfloatViewBottomSize;
	public int mDisplayWidth;
	float downX;
	float downY;
	private boolean listViewState = false;
	String fps = null;
	// 设置的初始化参数-回放次数
	LayoutParams wmSettingFequViewParams;
	LayoutParams wmkeyboardParams;
	// 设置回放次数确定
	Button btn_frequency;
	// 设置脚本数据
	private Adapter setAdapter;
	List<ScriptObj> list = new ArrayList<ScriptObj>();
	ScriptObj scriptObj = null;
	// 设置回放次数
	View mSettingFequView;
	View editView;// 回放次数编辑器
	EditText editText;// 回访次数编辑框
	Boolean isOK = false;// 是否编辑完成
	int isV = -1;// 大于1是激活
	// 记录当前设置回放次数
	public int frequecy = 1;
	public int tmpfp = 0;
	// 监听键盘是否关闭
	KeyBoardCloseListener keyBoardCloseListener;
	NodeClickFailListener nodeClickFailListener;
	// 回放时候控件点击失败
	boolean isFail = false;
	// 失败显示View
	View errorView;
	TextView textView;// 错误信息
	Button button;// 确认按钮
	int errorvis = 0;
	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case 0:
				Log.i(TAG, "handler msg");
				mFloatView.setVisibility(View.INVISIBLE);
				mContainView.setVisibility(View.VISIBLE);
				mWindowManager.updateViewLayout(mContainView, wmContainParams);
				break;
			case 1:
				mContainView.setVisibility(View.INVISIBLE);
				mFloatView.setVisibility(View.VISIBLE);
				// mWindowManager.updateViewLayout(mFloatView, wmFloatParams);
				break;

			default:
				break;
			}
		};
	};

	// 更新进度回放UI，反馈用户
	@SuppressLint("HandlerLeak")
	Handler errorhandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if (msg.what == 0) {
				Logger.i(TAG, "tmpfp==frequecy:" + (tmpfp == frequecy));
				if (tmpfp == frequecy)
					showErrorDialog(FloatWindowService.this, msg.obj.toString());
				else
					Logger.i(TAG, "循环回放，最后一次提示回放结束。");
			}
			if (msg.obj.toString().equals("回放结束!")) {
				GotoHome();
			}
		};
	};

	@Override
	public IBinder onBind(Intent intent) {
		// TODO 自动生成的方法存根
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO 自动生成的方法存根
		createFloatView();
		// initUi();
		Logger.i(TAG, "onStartCommand,pid:" + android.os.Process.myPid());
		return super.onStartCommand(intent, flags, startId);
	}

	private void createFloatView() {
		mWindowManager = (WindowManager) getApplication().getSystemService(
				Context.WINDOW_SERVICE);
		sW = mWindowManager.getDefaultDisplay().getWidth();
		sH = mWindowManager.getDefaultDisplay().getHeight();
		mFloatViewSize = getResources().getDimensionPixelSize(
				R.dimen.float_button_view_size);

		initFloatParams(0, sH / 2);// windowParams
		initContainParams(0, sH / 2);
		initSettingsParams(0, sH / 2);

		// initSettingsFrequencyParams(0, sH / 2);
		initFloatKeyBoardParams(sW, sH);

		initErrorViewParams(sW, sH);

		LayoutInflater inflater = LayoutInflater.from(this);
		// 加载悬浮按钮view，并停靠在手机屏幕左边
		mFloatView = inflater.inflate(R.layout.float_view, null);
		mFloatImageView = (FloatView) mFloatView.findViewById(R.id.float_view);
		mWindowManager.addView(mFloatView, wmFloatParams);
		// 加载悬浮按钮并显示菜单项,但不显示出来，只有点击后才能看到.初始化INVISIBLE
		mContainView = inflater.inflate(R.layout.float_contain, null);
		mWindowManager.addView(mContainView, wmContainParams);
		mContainView.setVisibility(View.INVISIBLE);
		// settings
		mSettingsView = inflater.inflate(R.layout.settings, null);
		listView = (ListView) mSettingsView.findViewById(R.id.list_settings);

		startRecord = (ImageView) mContainView.findViewById(R.id.begin_record);
		stopRecord = (ImageView) mContainView.findViewById(R.id.end_record);
		backRecord = (ImageView) mContainView.findViewById(R.id.paly_record);
		setting = (ImageView) mContainView.findViewById(R.id.setting_contain);

		startRecord.setOnClickListener(new ImageViewClickListener());
		stopRecord.setOnClickListener(new ImageViewClickListener());
		backRecord.setOnClickListener(new ImageViewClickListener());
		setting.setOnClickListener(new ImageViewClickListener());
		mFloatImageView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.i(TAG, "CLICK IMANGE");
				Message msg = Message.obtain();
				msg.what = 1;
				handler.sendMessage(msg);
			}
		});
	}

	private void initFloatParams(int x, int y) {
		wmFloatParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		wmFloatParams.type = LayoutParams.TYPE_SYSTEM_ALERT;//
		wmFloatParams.format = PixelFormat.RGBA_8888;
		wmFloatParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		wmFloatParams.gravity = Gravity.LEFT | Gravity.TOP;
		wmFloatParams.x = x;
		wmFloatParams.y = y;
		wmFloatParams.width = mFloatViewSize;
		wmFloatParams.height = mFloatViewSize;
		mDisplayWidth = mWindowManager.getDefaultDisplay().getWidth();
		wmFloatParams.windowAnimations = android.R.style.Animation_Dialog;
	}

	private void initContainParams(int x, int y) {
		wmContainParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		wmContainParams.type = LayoutParams.TYPE_SYSTEM_ALERT;//
		wmContainParams.format = PixelFormat.RGBA_8888;
		wmContainParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		wmContainParams.gravity = Gravity.LEFT | Gravity.TOP;
		wmContainParams.x = x;
		wmContainParams.y = y;
		wmContainParams.width = 350;
		wmContainParams.height = 620;
		wmContainParams.windowAnimations = android.R.style.Animation_Dialog;
	}

	private void initSettingsParams(int x, int y) {
		wmSettingsParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		wmSettingsParams.type = LayoutParams.TYPE_SYSTEM_ALERT;//
		wmSettingsParams.format = PixelFormat.RGBA_8888;
		wmSettingsParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		wmSettingsParams.gravity = Gravity.LEFT | Gravity.TOP;
		wmSettingsParams.x = sW / 3;
		wmSettingsParams.y = sH / 5;
		wmSettingsParams.width = 620;
		wmSettingsParams.height = 620;
		wmSettingsParams.windowAnimations = android.R.style.Animation_Dialog;
	}

	private void initErrorViewParams(int x, int y) {
		wmErrorViewParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		wmErrorViewParams.type = LayoutParams.TYPE_SYSTEM_ALERT;//
		wmErrorViewParams.format = PixelFormat.RGBA_8888;
		wmErrorViewParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		wmErrorViewParams.gravity = Gravity.LEFT | Gravity.TOP;
		wmErrorViewParams.x = sW / 4 - 60;
		wmErrorViewParams.y = sH / 4 + 150;
		wmErrorViewParams.width = sW / 2 + 150;
		wmErrorViewParams.height = sH / 6 + 150;
		wmErrorViewParams.windowAnimations = android.R.style.Animation_Dialog;
	}

	public class ImageViewClickListener implements OnClickListener {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.begin_record:
				replayList.clear();
				replayName = "";
				Log.i(TAG, "begin_record");
				Message msg = Message.obtain();
				msg.what = 1;
				handler.sendMessage(msg);
				if (!isStartRecord) {
					Logger.i(TAG, "开始录制---------- ");
					Utils.showDialog(FloatWindowService.this, "开始录制...", 1500);
					UiAutomatorRunner.getInstance().initialize();
					UiAutomatorRunner.bRecord = true;
					isStartRecord = true;
					UiAutomatorRunner.clickFirst = true;
					RecordManager.recordList.clear();
					registerEventListener();
				} else {
					Logger.i(TAG, "已经开始录制---------- ");
				}
				GotoHome();
				break;
			case R.id.end_record:
				replayName = "";
				Log.i(TAG, "end_record");
				msg = Message.obtain();
				msg.what = 1;
				handler.sendMessage(msg);
				if (isStartRecord) {
					UiAutomatorRunner.bRecord = false;
					isStartRecord = false;
					UiAutomatorRunner.clickFirst = false;
					Logger.i(TAG, "结束录制---------- ");
				} else {
					Logger.i(TAG, "还未启动录制---------- ");
				}
				Logger.i(TAG, "Record size: " + RecordManager.recordList.size());
				// 把结果写入到文件里面
				try {
					Utils.writeNodeInfoToFile(RecordManager.recordList);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					Logger.i(TAG, "录制数据写入文件是失败: " + e.toString());
				}
				GotoHome();
				// Utils.showDialog(FloatWindowService.this,"结束录制...",1000);
				break;
			case R.id.paly_record:
				UiAutomatorRunner.getInstance().initialize();
				Log.i(TAG, "paly_record ");
				// Utils.showDialog(FloatWindowService.this,"开始回放...",1000);
				msg = Message.obtain();
				msg.what = 1;
				handler.sendMessage(msg);
				// int fp = fps == null ? 0 : Integer.parseInt(fps);
				new Thread() {
					@Override
					public void run() {
						for (tmpfp = 0; tmpfp < frequecy;) {
							// 只有回放多次的时候才加回放间隔
							if (tmpfp > 1) {
								// 每次回放间隔2秒
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							tmpfp++;
							Logger.i(TAG, "当前回放次数:tmpfp:" + (tmpfp));
							if (isStartPlay) {
								isStartPlay = false;
								Logger.i(TAG, "开始回放---------- ");
								// GotoHome();

								// String defaultInputMethod =
								// Settings.Secure.getString(MyApplication.getContext().getContentResolver(),
								// "default_input_method");
								// Logger.i(TAG,
								// "当前默认输入法是---------- "+defaultInputMethod);
								// Settings.Secure.putString(MyApplication.getContext().getContentResolver(),
								// "default_input_method","jp.jun_nama.test.utf7ime/.Utf7ImeService");
								// Logger.i(TAG,
								// "设置默认输入法为---------- "+"jp.jun_nama.test.utf7ime/.Utf7ImeService");
								if (!Utils.isNullOrBlank(replayName)) {

									Logger.i(TAG, "开始回放选中的脚本---------- ");
									Logger.i(TAG, "node个数---------- "
											+ replayList.size());
									Logger.i(TAG, "本次循环执行次数：" + frequecy);
									RecordManager.runRecords(
											FloatWindowService.this,
											replayList,
											String.valueOf(frequecy));
								} else {
									Logger.i(TAG, "开始回放当前录制的脚本---------- ");
									RecordManager.runRecords(
											FloatWindowService.this,
											RecordManager.recordList,
											String.valueOf(frequecy));
								}
								// Logger.i(TAG,
								// "还原默认输入法是---------- "+defaultInputMethod);
								// Settings.Secure.putString(MyApplication.getContext().getContentResolver(),
								// "default_input_method",defaultInputMethod);
								isStartPlay = true;
							} else {
								Logger.i(TAG, "已经在回放---------- ");
							}
						}
					}
				}.start();
				// 回放监听器
				RecordManager
						.setNodeClickFailListener(new NodeClickFailListener() {
							@Override
							public void onNodeClickFail(boolean success,
									String message) {
								isFail = success;
								Logger.i(TAG, "回放提示信息监听器,reasult:" + success);
								Message msg = Message.obtain();
								msg.what = 0;
								msg.obj = message;
								errorhandler.sendMessage(msg);
							}
						});
				break;
			case R.id.setting_contain:
				if (listViewState) {
					mWindowManager.removeView(mSettingsView);
					listViewState = false;
					// 只有在View已经加载出来后才做处理
					if (isV > -1) {
						mWindowManager.removeView(editView);
						isV = -1;
					}
				} else {
					addSettingView();
				}

				// Log.i(TAG, "close_contain");
				// msg = Message.obtain();
				// msg.what = 1;
				// handler.sendMessage(msg);
				break;

			default:
				// msg = Message.obtain();
				// msg.what = 1;
				// handler.sendMessage(msg);
				break;
			}
		}
	}

	/**
	 * 初始化软键盘菜单
	 */
	private void initFloatKeyBoardParams(int sW, int sH) {

		Log.i(TAG, "initFloatParams");
		wmkeyboardParams = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		wmkeyboardParams.type = LayoutParams.TYPE_SYSTEM_ALERT;//
		wmkeyboardParams.format = PixelFormat.RGBA_8888;
		wmkeyboardParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
		wmkeyboardParams.gravity = Gravity.LEFT | Gravity.TOP;
		wmkeyboardParams.x = sW / 3 + 100;
		wmkeyboardParams.y = sH / 4;
		wmkeyboardParams.width = sW / 5 * 2;
		wmkeyboardParams.height = sH / 7 * 2;
		wmkeyboardParams.windowAnimations = android.R.style.Animation_Dialog;
	}

	/**
	 * 回放结束提示信息20170608sunyinglong
	 */
	public boolean showErrorDialog(FloatWindowService service, String errorInfo) {
		Logger.i(TAG, "show replayView Dialog");
		LayoutInflater inflater = LayoutInflater.from(service);
		errorView = inflater.inflate(R.layout.show_replay_error, null);
		textView = (TextView) errorView.findViewById(R.id.error_info);
		textView.setText(errorInfo);
		button = (Button) errorView.findViewById(R.id.btn_OK);
		if (errorvis == 1) {
			mWindowManager.removeView(errorView);
			errorvis = 0;
		} else {
			mWindowManager.addView(errorView, wmErrorViewParams);
			errorvis = 1;
		}
		button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mWindowManager.removeView(errorView);
				errorvis = 0;
				Logger.i(TAG, "remove replayView Dialog");
			}
		});
		return true;
	}

	/**
	 * 回放次数编辑提示信息20170608sunyinglong
	 */
	public boolean showEditTextDialog(FloatWindowService service) {
		frequecy = 1;
		Log.i(TAG, "show Edit Dialog");
		// initFloatKeyBoardParams();
		Log.i(TAG, "LayoutInflater");
		LayoutInflater inflater = LayoutInflater.from(service);
		editView = inflater.inflate(R.layout.setting_frequency, null);
		editText = (EditText) editView.findViewById(R.id.playfrequency1);
		btn_frequency = (Button) editView.findViewById(R.id.btn_frequency);
		// editText.setText(1 + "");
		Log.i(TAG, "show Edit Dialog");
		if (isV > -1)
			mWindowManager.removeView(editView);
		else
			mWindowManager.addView(editView, wmkeyboardParams);
		isV = 1;// 设置编辑框是否显示

		// 直接调出键盘
		int inputback = editText.getInputType();
		editText.setInputType(InputType.TYPE_NULL);
		new KeyboardUtil(editView, MyApplication.getContext(), editText,
				mWindowManager).showKeyboard();
		editText.setInputType(inputback);
		// 接收编辑是否已经完成,键盘是否已经关闭，
		new KeyboardUtil(editView, MyApplication.getContext(), editText,
				mWindowManager)
				.setKeyBoardStateListener(new KeyBoardCloseListener() {
					@Override
					public void onCloseKeyBoard(boolean isok) {
						isOK = isok;
						// 编辑“完成”，移除编辑窗口
						mWindowManager.removeView(editView);
						// 回放次数设置完毕,移除列表窗口
						mWindowManager.removeView(mSettingsView);
						listViewState = false;
						isOK = false;
						Logger.i(TAG, "finish keyboard Listener isOK:" + isOK
								+ ",isV:" + isV);
					}

					@Override
					public void onVisibilityKeyBoard(int v) {
						isV = v;
						Logger.i(TAG, "keyboard visiblity listener isV:" + isV);
					}

					@Override
					public void onSaveFrequecy(String frequecyStr) {
						// Logger.i(TAG, "frequecy 1：" + editText.getText());
						// Logger.i(TAG, "frequecy 2：" + frequecyStr);
						frequecy = frequecyStr == null
								|| frequecyStr.equalsIgnoreCase("") ? 1
								: Integer.parseInt(frequecyStr);
					}
				});
		btn_frequency.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isV > -1)
					mWindowManager.removeView(editView);
				isV = -1;
			}
		});
		Log.i(TAG, "remove Edit Dialog");
		return isOK;
	}

	// 脚本列表显示
	public void addSettingView() {
		mWindowManager.addView(mSettingsView, wmSettingsParams);
		listViewState = true;
		String[] data = null;
		list.clear();
		fileList.clear();
		String strPath = getApplication().getFilesDir().getPath();
		Logger.i(TAG, "filePath:" + strPath);
		File file = new File(strPath);
		if (file.exists()) {
			File[] files = file.listFiles();
			int j = 0;
			if (files != null) {
				for (int i = 0; i < files.length; i++) {
					if (!files[i].isDirectory()) { // 判断是文件还是文件夹
						if (files[i].getName().endsWith(".json")) {
							fileList.add(files[i].getName()
									.replace(".json", ""));
							j++;
						}
					}
				}
			}
			if (j > 0) {
				// data = new String[j];
				for (int k = 0; k < j; k++) {
					// data[k] = fileList.get(k);
					scriptObj = new ScriptObj();
					scriptObj.setName(fileList.get(k));
					scriptObj.setFrequency(1);
					list.add(scriptObj);
				}
			} else {
				// data = new String[1];
				// data[0] = "没有录制的数据";
				scriptObj = new ScriptObj();
				scriptObj.setName("没有录制的数据");
				scriptObj.setFrequency(0);
				list.add(scriptObj);
			}
		}

		// 获取文件列表
		// ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
		// R.layout.list_item, R.id.setting_item_text, data);
		// listView.setAdapter(adapter);
		setAdapter = new Adapter(FloatWindowService.this, list);
		listView.setAdapter(setAdapter);
		// listView.setOnClickListener(new Onc)
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (fileList == null || fileList.size() == 0)
					return;
				replayName = fileList.get(position);
				Log.i(TAG, "replay name:" + replayName);
				String replayData = Utils.load(getApplicationContext(),
						replayName + ".json");
				Log.i(TAG, "replay data:" + replayData);
				replayList.clear();
				// String tempStringBuf =
				// "[{'action':'ACTION_STARTACTIVITY','packageName':'com.android.settings/com.android.settings.HWSettings'},{'action':'ACTION_CLICK','allowScroll':true,'locationType':'ATTR','id':'id/title','text':'Display'}]";
				// System.out.println(tempStringBuf.toString());
				// if (tempStringBuf != null) {
				Gson gson = new Gson();
				JsonParser jsonParser = new JsonParser();
				JsonArray jsonArray = jsonParser.parse(replayData)
						.getAsJsonArray();
				for (JsonElement jsonElement : jsonArray) {
					// System.out.println(jsonElement.toString());
					Log.i(TAG, "replay node:" + jsonElement.toString());
					NodeInfoAction nodeInfoAction = gson.fromJson(jsonElement,
							NodeInfoAction.class);
					LOCALTYPE localType = null;
					if (nodeInfoAction.getLocationType() == null) {
						localType = LOCALTYPE.NONE;
					} else if (nodeInfoAction.getLocationType().equals(
							"WIDGETATTR")) {
						localType = LOCALTYPE.WIDGETATTR;
					} else if (nodeInfoAction.getLocationType().equals("AXIS")) {
						localType = LOCALTYPE.AXIS;
					}
					Log.i(TAG, "id:" + nodeInfoAction.getId() + " text:"
							+ nodeInfoAction.getText() + " actionType:"
							+ nodeInfoAction.getAction() + " inputText:"
							+ nodeInfoAction.getInputText() + " LOCALTYPE:"
							+ localType.toString() + " isAllowScroll:"
							+ nodeInfoAction.isAllowScroll() + " packageName:"
							+ nodeInfoAction.getPackageName() + " nodeX:"
							+ nodeInfoAction.getNodeX() + " nodeY:"
							+ nodeInfoAction.getNodeY());
					RecordInfo recordInfo = new RecordInfo(nodeInfoAction
							.getId(), nodeInfoAction.getText(), nodeInfoAction
							.getAction(), nodeInfoAction.getInputText(),
							localType, nodeInfoAction.isAllowScroll(),
							nodeInfoAction.getPackageName(), nodeInfoAction
									.getNodeX(), nodeInfoAction.getNodeY());
					replayList.add(recordInfo);
					Log.i(TAG, "replay size:" + replayList.size());

				}
				// 调用数字键盘设置回访次数
				if (isV == -1)
					showEditTextDialog(FloatWindowService.this);
			}

		});
	}

	@Override
	public void onDestroy() {
		// if (hasAddEat) {
		// mWindowManager.removeView(eatBeanMan);
		// }
		mWindowManager.removeView(mFloatView);
		mWindowManager.removeView(mContainView);
		super.onDestroy();
	}

	/**
	 * 注册事件监听事件
	 * 
	 * @param context
	 * @param params
	 */
	private void registerEventListener() {
		Logger.i(TAG, "registerEventListener!");
		UiAutomatorRunner.getInstance().addListener();
	}

	public void GotoHome() {
		// 隐藏activity到后台,打开HOME Launcher
		PackageManager pm = getPackageManager();
		ResolveInfo homeInfo = pm.resolveActivity(
				new Intent(Intent.ACTION_MAIN)
						.addCategory(Intent.CATEGORY_HOME), 0);
		ActivityInfo ai = homeInfo.activityInfo;
		Intent startIntent = new Intent(Intent.ACTION_MAIN);
		startIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		startIntent.setComponent(new ComponentName(ai.packageName, ai.name));
		startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		try {
			startActivity(startIntent);
		} catch (ActivityNotFoundException e) {
			Logger.i(TAG, "not found Activity error=" + e.getMessage());
		} catch (SecurityException e) {
			Logger.i(TAG, "not found Activity error=" + e.getMessage());
			Logger.e(
					TAG,
					"Launcher does not have the permission to launch "
							+ startIntent
							+ ". Make sure to create a MAIN intent-filter for the corresponding activity "
							+ "or use the exported attribute for this activity."
							+ e);
		}
	}

	public void updateViewPosition(int action, float x, float y,
			float mTouchStartX, float mTouchStartY) {
		// boolean isOut = true;
		// if (Math.abs(positionX - startX) < MAXDIS
		// && Math.abs(positionY - startY) < MAXDIS) {
		// isOut = false;
		// }
		int deltaX = (int) (x - mTouchStartX);
		int deltaY = (int) (y - mTouchStartY);
		if (action == MotionEvent.ACTION_DOWN) {
			downX = x;
			downY = y;

			Log.i(TAG, "down X:" + downX);
			Log.i(TAG, "down Y:" + downY);
		} else if (action == MotionEvent.ACTION_MOVE) {
			wmFloatParams.x = deltaX;
			wmFloatParams.y = deltaY;
			mWindowManager.updateViewLayout(mFloatView, wmFloatParams);
			Log.i(TAG, "move deltaX:" + Math.abs(x - mTouchStartX));
			Log.i(TAG, "move deltaY:" + Math.abs(y - mTouchStartY));
		} else if (action == MotionEvent.ACTION_UP) {

			wmFloatParams.y = deltaY;
			if (x < mDisplayWidth / 2) {
				wmFloatParams.x = 0;
			} else {
				wmFloatParams.x = mDisplayWidth;
			}
			mWindowManager.updateViewLayout(mFloatView, wmFloatParams);
			wmContainParams.x = wmFloatParams.x;
			wmContainParams.y = wmFloatParams.y;
			Log.i(TAG, "up deltaX:" + Math.abs(downX - x));
			Log.i(TAG, "up deltaY:" + Math.abs(downY - y));
			if (Math.abs(downX - x) < MINDIS && Math.abs(downY - y) < MINDIS) {
				// 认为是点击事件，弹出contain窗口
				Log.i(TAG, "弹出contain窗口");
				Message msg = Message.obtain();
				msg.what = 0;
				handler.sendMessage(msg);
			}
		}
	}

	/**
	 * @author sunyi 20170604 键盘激活监听，编辑“完成”监听,按键监听
	 */
	public static interface KeyBoardCloseListener {
		public void onVisibilityKeyBoard(int v);

		public void onCloseKeyBoard(boolean isok);

		public void onSaveFrequecy(String frequecyStr);
	}

	/**
	 * @author sunyi 20170607 控件点击失败监听
	 */
	public static interface NodeClickFailListener {
		public void onNodeClickFail(boolean success, String message);
	}
}
